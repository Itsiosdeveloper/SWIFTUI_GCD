//
//  ContentView.swift
//  SWIFTUI_GCD
//
//  Created by SMH on 19/06/24.
//

import SwiftUI

// MARK: - Model Structures
struct Post: Codable { // Model structure for Post fetched from API
    let id: Int
    let title: String
    let body: String
}

struct User: Codable { // Model structure for User fetched from API
    let id: Int
    let name: String
    let email: String
}

struct Comment: Codable { // Model structure for Comment fetched from API
    let id: Int
    let name: String
    let email: String
    let body: String
}

// MARK: - Functions for API Calls
func fetchPosts(completion: @escaping ([Post]?, Error?) -> Void) {
    let url = URL(string: "https://jsonplaceholder.typicode.com/posts")! // API endpoint for fetching posts
    URLSession.shared.dataTask(with: url) { data, response, error in // URLSession for network request
        if let error = error { // Error handling
            completion(nil, error) // Completion with error if there's an error
            return
        }
        guard let data = data else { // Ensure data is valid
            completion(nil, NSError(domain: "No data", code: -1, userInfo: nil)) // Completion with error if no data
            return
        }
        do { // Parsing JSON data
            let posts = try JSONDecoder().decode([Post].self, from: data) // Decoding JSON to Post array
            completion(posts, nil) // Completion with decoded posts
        } catch {
            completion(nil, error) // Completion with decoding error
        }
    }.resume() // Start URLSession task
}

func fetchUsers(completion: @escaping ([User]?, Error?) -> Void) {
    let url = URL(string: "https://jsonplaceholder.typicode.com/users")! // API endpoint for fetching users
    URLSession.shared.dataTask(with: url) { data, response, error in // URLSession for network request
        if let error = error { // Error handling
            completion(nil, error) // Completion with error if there's an error
            return
        }
        guard let data = data else { // Ensure data is valid
            completion(nil, NSError(domain: "No data", code: -1, userInfo: nil)) // Completion with error if no data
            return
        }
        do { // Parsing JSON data
            let users = try JSONDecoder().decode([User].self, from: data) // Decoding JSON to User array
            completion(users, nil) // Completion with decoded users
        } catch {
            completion(nil, error) // Completion with decoding error
        }
    }.resume() // Start URLSession task
}

func fetchComments(completion: @escaping ([Comment]?, Error?) -> Void) {
    let url = URL(string: "https://jsonplaceholder.typicode.com/comments")! // API endpoint for fetching comments
    URLSession.shared.dataTask(with: url) { data, response, error in // URLSession for network request
        if let error = error { // Error handling
            completion(nil, error) // Completion with error if there's an error
            return
        }
        guard let data = data else { // Ensure data is valid
            completion(nil, NSError(domain: "No data", code: -1, userInfo: nil)) // Completion with error if no data
            return
        }
        do { // Parsing JSON data
            let comments = try JSONDecoder().decode([Comment].self, from: data) // Decoding JSON to Comment array
            completion(comments, nil) // Completion with decoded comments
        } catch {
            completion(nil, error) // Completion with decoding error
        }
    }.resume() // Start URLSession task
}

// MARK: - SwiftUI ContentView
struct ContentView: View {
    @State private var posts: [Post] = [] // State variable to hold fetched posts
    @State private var users: [User] = [] // State variable to hold fetched users
    @State private var comments: [Comment] = [] // State variable to hold fetched comments
    @State private var isLoading: Bool = false // State variable to manage loading state
    @State private var loadingTime: TimeInterval = 0 // State variable to store loading time
    @State private var showProgress: Bool = false // State variable to control progress animation

    var body: some View {
        ScrollView { // Scrollable container for content
            VStack(spacing: 20) { // Vertical stack for arranging content with spacing
                if isLoading { // Display loading progress if data is loading
                    ProgressView("Loading Data...") // Show loading text
                        .progressViewStyle(CircularProgressViewStyle()) // Circular progress indicator style
                } else { // Display fetched data
                    VStack(spacing: 20) { // Vertical stack for displaying fetched data
                        ForEach(posts.prefix(3), id: \.id) { post in // Display first three posts
                            Text("\(post.title)") // Post title
                                .font(.headline) // Headline font
                                .padding() // Padding around text
                        }
                        ForEach(users.prefix(3), id: \.id) { user in // Display first three users
                            Text("\(user.name)") // User name
                                .font(.headline) // Headline font
                                .padding() // Padding around text
                        }
                        ForEach(comments.prefix(3), id: \.id) { comment in // Display first three comments
                            Text("\(comment.body)") // Comment body
                                .font(.body) // Body font
                                .padding() // Padding around text
                        }
                    }
                }
                
                // Button to simulate data fetching
                Button(action: {
                    fetchData() // Fetch data when button is tapped
                }) {
                    Text("Fetch Data") // Button text
                        .padding() // Padding around text
                        .background(Color.blue) // Blue background color
                        .foregroundColor(.white) // White text color
                        .cornerRadius(8) // Rounded corners
                }
                .padding() // Padding around button
            }
            .onAppear { // When view appears
                showProgress = true // Show progress animation
                fetchData() // Fetch data
            }
            .padding() // Padding around VStack
        }
    }
    
    // Function to fetch data from APIs
    private func fetchData() {
        isLoading = true // Set loading state to true
        showProgress = true // Show progress animation
        
        let startTime = Date() // Start time to calculate loading time
        
        let group = DispatchGroup() // Dispatch group for concurrent tasks
        
        // Fetch posts concurrently
        group.enter() // Enter dispatch group
        fetchPosts { fetchedPosts, error in // Fetch posts
            defer { group.leave() } // Leave dispatch group when done
            if let fetchedPosts = fetchedPosts { posts = fetchedPosts } // Assign fetched posts
            if let error = error { print("Error fetching posts: \(error)") } // Log error if any
        }
        
        // Fetch users concurrently
        group.enter() // Enter dispatch group
        fetchUsers { fetchedUsers, error in // Fetch users
            defer { group.leave() } // Leave dispatch group when done
            if let fetchedUsers = fetchedUsers { users = fetchedUsers } // Assign fetched users
            if let error = error { print("Error fetching users: \(error)") } // Log error if any
        }
        
        // Fetch comments concurrently
        group.enter() // Enter dispatch group
        fetchComments { fetchedComments, error in // Fetch comments
            defer { group.leave() } // Leave dispatch group when done
            if let fetchedComments = fetchedComments { comments = fetchedComments } // Assign fetched comments
            if let error = error { print("Error fetching comments: \(error)") } // Log error if any
        }
        
        group.notify(queue: .main) { // When all tasks in group are done
            isLoading = false // Set loading state to false
            showProgress = false // Hide progress animation
            loadingTime = Date().timeIntervalSince(startTime) // Calculate loading time
        }
    }
}

// MARK: - Preview
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}



