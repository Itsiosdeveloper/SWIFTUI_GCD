//
//  SWIFTUI_GCDApp.swift
//  SWIFTUI_GCD
//
//  Created by SMH on 19/06/24.
//

import SwiftUI

@main
struct SWIFTUI_GCDApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
